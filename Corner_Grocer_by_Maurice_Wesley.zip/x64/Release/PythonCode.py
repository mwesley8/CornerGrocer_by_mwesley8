import re
import string

def readList():
    # Function to read csv file and create dictionary of item and frequency
    with open("CS_210_Project_Three_Input_File.txt", "r") as f:
        myfile = f.readlines()
        orderFrequency = {}
        # If file is open read csv
        if (myfile):
            lines = myfile
            for line in lines:
                # If not in dictionary
                if line.strip() not in orderFrequency:
                    orderFrequency[line.strip()] = 1
                # If in dictionary then increment value
                else:
                    orderFrequency[line.strip()] += 1
        else:
            print("File cannot be opened")
        # Return dictionary
        return orderFrequency

def printList():
    # Function to print out key value pairs in dictionary
    orderFrequency = readList()

    print("\n   Item    : Frequency")
    print("_" * 22)
    # Iterate over key value pairs in dictionary
    for key,value in orderFrequency.items():
        print(f'{key}{" " * (11 - len(key))}:     {value}')
    print("_" * 22)
    print("")
    
    return 0

def writeFile():
    # Function to write a file using the call function to create a dictionary
    orderFrequency = readList()
    with open("frequency.dat", "w") as f:
        datFile = f
        if (datFile):
            # Write to file
            datFile.write("Item,Frequency\n")
            # Interate over key value pairs and write to file
            for key,value in orderFrequency.items():
                datFile.write(f'{key},{value}\n')
        else:
            print("File cannot be opened.\n")

    return 0

def specificItem(product):
    # Function to output a specific item and frequency
    shoppingList = readList()
    # Create temporty list of items for search validation
    itemsList = []
    # Add items to list
    for keys in shoppingList.keys():
        itemsList.append(keys.lower())
    # If item in list return value
    if product.lower() in itemsList:
        for key, value in shoppingList.items():
            if product.lower() == key.lower():
                return value
    # If item not in list return zero
    else:
        return 0


